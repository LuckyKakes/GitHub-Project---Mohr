//image variables
let img;
let blu;
let banan;

function preload(){
  //preload images
  img = loadImage('assets/hermit crab.avif');
  blu = loadImage('assets/blue hermit crab.avif');
  banan = loadImage('assets/banana.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  
  //load images
  image(img, -10, 360, 230, -mouseY);
  image(blu, 200, 350, 200, -mouseY);
  image(banan, mouseX, mouseY, 200, 115);
  
  //text
  textAlign(CENTER);
  textFont('Impact');
  textSize(50);
  strokeWeight(3);
  stroke(0, 0, 0);
  fill(255, 255, 255);
  //regular text
  text('BANANA', 200, 390);
  //using width and height
  text('YUMMY', 0, 0, 400, 100);
}