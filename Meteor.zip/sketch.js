function setup() {
    createCanvas(1280, 720);
    colorMode(RGB);
}

function draw() {
    background(0,0, 0);
    //meteor
    stroke(255, 255, 0);
    strokeWeight(5);
    animS.line('l1', 60, 0, 0, 1280, 720)
    stroke(45)
    strokeWeight(6)
    animS.line('l2', 70, 0, 0, 1280, 720)
    //circle
    fill(255, 56, 59);
    stroke(255, 56, 59);
    strokeWeight(5)
    animS.circle('c1', 50, 1280, 720, 500);
}

function mouseClicked() {
    animS.reset();
}