function setup() {
  createCanvas(128, 128);
  colorMode(RGB)
}

function draw() {
  //Black Background
  background(0, 100, 255, 15);
  
  //background 2
  beginShape();
  //shape1
  stroke(0, 0, 255, 50);
  fill(0, 0, 255, 150);
  vertex(5, 5);
  vertex(5, 123);
  vertex(123, 123);
  vertex(123, 5);
  //shape2
  beginContour();
  vertex(100, 25);
  vertex(115, 115);
  vertex(25, 100);  
  vertex(15, 15);
  endContour();
  endShape(CLOSE);
  
  //Curve
  stroke(255)
  strokeWeight(2);
  noFill();
  curve(5, 90, 55, 128, 64, 95, 15, 64);
  
  //Balloon 1
  stroke(200, 0, 0, 255);
  strokeWeight(3);
  fill(255, 0, 0);
  triangle(54, 95, 64, 84, 74, 95);
  ellipse(64, 54, 55, 65);
  
  
  
}